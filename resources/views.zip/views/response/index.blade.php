
<html>
    <title></title>
    <head>
        <meta name="csrf-token" content="{{ csrf_token() }}">
    </head>
    <body>
<div class="page-wrapper">
    <div class="container-fluid">
        <div class="row">
            <div class="col l6 m6 s6">
                <h4 class="font-medium">Payment Successfully Done</h4>
            </div>
        </div><hr>
        </body>
</html>